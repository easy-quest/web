---
title: Nocode
layout: 2017/sheet
updated: 2018-03-17
intro: |
  [Nocode](https://github.com/kelseyhightower/nocode) is the best way to write secure and reliable applications. Write nothing; deploy nowhere.
---

## Nothing
{: .-one-column}

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
