---
title: eslint
category: JavaScript libraries
---

```js
// "comma-dangle": "always" ("always-multiline", "never")
var foo = {
    bar: "baz",
    qux: "quux",
};
var arr = [1,2,];
```

```
// "yoda": "always" ("never")
if ("red" === color)
```
