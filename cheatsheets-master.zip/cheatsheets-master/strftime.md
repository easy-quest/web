---
title: strftime format
layout: 2017/sheet
weight: -5
updated: 2017-11-27
tags: [Featurable]
intro: |
  The strftime format is the standard date formatting for UNIX. It's used in C, Ruby, and more.
---

{% include common/strftime_format.md title="strftime" %}
