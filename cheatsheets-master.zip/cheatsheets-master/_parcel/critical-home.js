import 'sanitize.css'
import './critical-home.scss'
