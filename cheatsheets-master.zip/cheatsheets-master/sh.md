---
title: Shell scripting
category: CLI
redirect_to: /bash
---
