<h1 align='center'>Devhints</h1>

<blockquote align='center'>
TL;DR для разработчиков Документация - смешная коллекция обмана</blockquote>

<p align='center'>
Смотрите тестовые сборкиСмотрите тестовые сборкиСмотрите тестовые сборкиСмотрите тестовые сборки
Смотрите тестовые сборкиСмотрите тестовые сборкиСмотрите тестовые сборкиСмотрите тестовые сборкиСмотрите тестовые сборкиСмотрите тСмотрите тестовые сборки
<br>

<p align='center'>
<a href='xxxxxxx'><img src='_docs/images/png' width=600></a>
<br>
✨ <b><a href='zzzi.site'</a></b> ✨
</p>

<br>

---

See [CONTRIBUTING.md](CONTRIBUTING.md) для заметки разработчиков.